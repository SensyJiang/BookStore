
create procedure sp_AddCheck
@userId int
as
declare
@disName varchar(20)
set @disName = 'pp'
INSERT INTO stf_attend_ratio(att_stf_id,att_stf_name,att_day,att_time_from,att_dep)
VALUES
(@userId,
@disName,
CONVERT(VARCHAR(10),GETDATE(),120),
 convert(varchar(5),getdate(),108),
'产品研发部')
GO
